# SafeSphere

A demo cybersecurity and privacy dashboard built with React, TypeScript, Vite, Tailwind CSS, React Router and Lucide icons.

> **Demo only.** Every result is mocked: the health score comes from a fixed checklist, sessions and activity are seeded sample data, and monitoring is simulated. SafeSphere does **not** scan, monitor or protect any real account or device. It never asks for or stores passwords, codes or other secrets. Everything is saved in this browser's `localStorage` under the `safesphere:` prefix.

## Quick start
```bash
npm install
cp .env.example .env   # optional
npm run dev            # http://localhost:5173
npm test               # unit tests (Vitest)
npm run build          # type-check + production build into dist/
```
Requires Node 18+ (Node 20 recommended).

## Features
Overview (score ring, risk alerts, stats) · Checklist (weighted, persisted) · Link checker (offline heuristics) · Devices (trust, revoke, sign out others) · Privacy (toggles, export, delete) · Activity timeline (fed by your actions) · Settings (name, theme, simulated notifications, reset). Light and dark themes, toasts, skeleton loading, empty and error states, keyboard-accessible controls, skip link, focus management, and a mobile drawer (Esc closes it).

## Architecture
```
src/app/          shell: providers (theme, toasts, checklist), layout, routes
src/components/   reusable UI (Badge, Switch, ScoreRing, Skeleton, Empty ...)
src/features/     dashboard, checklist, links, devices, privacy, activity, settings
src/lib/          pure logic (score.ts, url.ts), storage + useAsync hooks
src/services/     mockApi.ts: the only data boundary; swap for real HTTP later
```
Score = sum of completed check weights / total weight (weights total 100). Link risk = additive heuristic points, capped at 100. Both are covered by unit tests.

## Production hardening path
1. **Real backend:** replace `services/mockApi.ts` with an HTTP client behind the same method names. Keep all secrets server-side (`VITE_*` values are public).
2. **Authentication:** use a vetted provider (OIDC/passkeys) with HttpOnly, Secure, SameSite cookies, server-side sessions, CSRF protection, and rate limiting. Never handle raw passwords in this client.
3. **Real signals:** derive session and device data from your auth server and audit logs. Use a real URL-reputation service (server-side, with consent) instead of the heuristics in `lib/url.ts`.
4. **Headers:** serve a strict CSP, HSTS, `X-Content-Type-Options`, `Referrer-Policy` and `frame-ancestors`. Self-host fonts to drop the Google Fonts dependency. Configure an SPA fallback to `index.html`.
5. **Quality gates:** add ESLint, component and Playwright tests (including axe accessibility checks), dependency audits, and error reporting. CI in `.github/workflows/ci.yml` already runs tests and the build.
6. **Privacy:** add a data-processing review, consent records, retention enforcement and deletion flows server-side.

## Push to GitHub
```bash
git init -b main && git add . && git commit -m "feat: SafeSphere dashboard MVP"
git remote add origin https://github.com/kushalkumarr231-boop/safesphere.git
git push -u origin main
```
