import { useState, type FormEvent } from 'react'
import { Moon, RotateCcw, Sun } from 'lucide-react'
import { useTheme, useToast } from '../../app/state'
import { useStored } from '../../lib/storage'
import { api } from '../../services/mockApi'
import { PageHeader, Switch } from '../../components/ui'

export const validAlias = (v: string) => /^[\p{L}\p{N} _-]{2,24}$/u.test(v.trim())
export default function SettingsPage() {
  const [alias, setAlias] = useStored('alias', 'Demo User')
  const [draft, setDraft] = useState(alias), [err, setErr] = useState('')
  const [n, setN] = useStored('notifications', { email: true, push: false, weekly: true })
  const { theme, setTheme } = useTheme(), toast = useToast()
  const [ask, setAsk] = useState(false)
  function save(e: FormEvent) {
    e.preventDefault()
    if (!validAlias(draft)) { setErr('Use 2 to 24 letters, numbers, spaces, hyphens or underscores.'); return }
    setErr(''); setAlias(draft.trim()); toast('Display name saved')
  }
  const rows: [keyof typeof n, string][] = [['email', 'Security alert emails'], ['push', 'Push notifications'], ['weekly', 'Weekly summary']]
  return (
    <>
      <PageHeader title="Settings" sub="Preferences for this demo. Notifications are simulated: no messages are ever sent." />
      <div className="grid gap-4 lg:grid-cols-2">
        <form className="card" onSubmit={save} noValidate>
          <h2 className="mb-3 font-semibold">Display name</h2>
          <label htmlFor="alias" className="sr-only">Display name</label>
          <input id="alias" className="input" value={draft} aria-invalid={!!err} aria-describedby="alias-hint" onChange={e => setDraft(e.target.value)} />
          <p id="alias-hint" role={err ? 'alert' : undefined} className={`mt-2 text-sm ${err ? 'text-rose-500' : 'muted'}`}>{err || 'A nickname for this demo. Never enter passwords, codes or personal data.'}</p>
          <button className="btn btn-primary mt-3">Save name</button>
        </form>
        <section className="card" aria-labelledby="h-theme">
          <h2 id="h-theme" className="mb-3 font-semibold">Theme</h2>
          <div className="flex gap-2" role="group" aria-label="Theme">
            {([['light', Sun], ['dark', Moon]] as const).map(([t, I]) => (
              <button key={t} className={`btn flex-1 capitalize ${theme === t ? '!border-teal-400 bg-teal-500/10' : ''}`} aria-pressed={theme === t} onClick={() => setTheme(t)}><I size={16} />{t}</button>
            ))}
          </div>
        </section>
        <section className="card" aria-labelledby="h-notif">
          <h2 id="h-notif" className="mb-2 font-semibold">Notifications <span className="muted font-normal">(simulated)</span></h2>
          {rows.map(([k, l]) => <div key={k} className="flex items-center justify-between py-2"><span>{l}</span><Switch label={l} checked={n[k]} onChange={v => { setN({ ...n, [k]: v }); toast(`${l} ${v ? 'enabled' : 'disabled'}`, 'info') }} /></div>)}
        </section>
        <section className="card" aria-labelledby="h-reset">
          <h2 id="h-reset" className="mb-1 font-semibold">Reset demo</h2>
          <p className="muted mb-3">Clears checklist progress, sessions, activity and preferences stored in this browser.</p>
          <button className="btn btn-danger" onBlur={() => setAsk(false)} onClick={() => { if (ask) { api.resetDemo(); location.reload() } else setAsk(true) }}><RotateCcw size={16} />{ask ? 'Click again to reset' : 'Reset demo data'}</button>
        </section>
      </div>
    </>
  )
}
