import { useState } from 'react'
import { LogOut, MonitorSmartphone } from 'lucide-react'
import { useToast } from '../../app/state'
import { useAsync } from '../../lib/useAsync'
import { api, type Session } from '../../services/mockApi'
import { Badge, Empty, ErrorBox, PageHeader, Skeleton, ago } from '../../components/ui'

export default function Devices() {
  const s = useAsync(api.sessions), toast = useToast()
  const [ask, setAsk] = useState<string | null>(null), [busy, setBusy] = useState(false)
  async function act(fn: () => Promise<Session[]>, msg: string) {
    setBusy(true)
    try { s.setData(await fn()); toast(msg) } catch { toast('That action failed. Try again.', 'err') }
    setBusy(false); setAsk(null)
  }
  const others = (s.data ?? []).filter(x => !x.current)
  return (
    <>
      <PageHeader title="Devices and sessions" sub="See where this demo account is signed in. These sessions are simulated.">
        <button className="btn btn-danger" disabled={!others.length || busy} onBlur={() => setAsk(null)}
          onClick={() => (ask === 'all' ? act(() => api.revokeOthers(), 'Signed out all other sessions') : setAsk('all'))}>
          <LogOut size={16} />{ask === 'all' ? 'Click again to confirm' : 'Sign out all others'}
        </button>
      </PageHeader>
      {s.loading ? <div className="space-y-3" aria-busy="true">{[0, 1, 2].map(i => <Skeleton key={i} className="h-20" />)}</div> : s.error ? <ErrorBox onRetry={s.reload} /> : (
        <>
          <ul className="space-y-3">{(s.data ?? []).map(x => (
            <li key={x.id} className="card flex flex-wrap items-center gap-4">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-violet-500/10 text-violet-500"><MonitorSmartphone size={20} /></div>
              <div className="min-w-0 flex-1"><p className="font-medium">{x.device}</p><p className="muted">{x.os}, {x.place}, {x.current ? 'active now' : ago(x.lastActive)}</p></div>
              {x.current ? <Badge sev="low">This device</Badge> : x.trusted ? <Badge sev="low">Trusted</Badge> : <Badge sev="high">Unrecognised</Badge>}
              {!x.current && (
                <div className="flex gap-2">
                  <button className="btn" disabled={busy} onClick={() => act(() => api.setTrust(x.id, !x.trusted), x.trusted ? 'Marked as unrecognised' : 'Marked as trusted')}>{x.trusted ? 'Untrust' : 'Trust'}</button>
                  <button className="btn btn-danger" disabled={busy} onBlur={() => setAsk(null)} onClick={() => (ask === x.id ? act(() => api.revoke(x.id), 'Session revoked') : setAsk(x.id))}>{ask === x.id ? 'Confirm revoke' : 'Revoke'}</button>
                </div>
              )}
            </li>
          ))}</ul>
          {others.length === 0 && <div className="mt-3"><Empty icon={MonitorSmartphone} title="No other sessions" text="Only this device is signed in. Use Settings to reset the demo data and restore the sample sessions." /></div>}
        </>
      )}
    </>
  )
}
