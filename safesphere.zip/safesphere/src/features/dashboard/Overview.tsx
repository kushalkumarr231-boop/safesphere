import { Link } from 'react-router-dom'
import { Laptop, ListChecks, ShieldCheck } from 'lucide-react'
import { useChecklist } from '../../app/state'
import { CHECKS, grade, pendingChecks, type Severity } from '../../lib/score'
import { useStored } from '../../lib/storage'
import { useAsync } from '../../lib/useAsync'
import { api } from '../../services/mockApi'
import { Badge, DOT, Empty, ErrorBox, PageHeader, ScoreRing, Skeleton, ago } from '../../components/ui'

export default function Overview() {
  const { done, score } = useChecklist()
  const [alias] = useStored('alias', 'Demo User')
  const s = useAsync(api.sessions), a = useAsync(api.activity)
  const g = grade(score), pending = pendingChecks(done)
  if (s.loading || a.loading) return <div className="grid gap-4 lg:grid-cols-3" aria-busy="true"><Skeleton className="h-72" /><Skeleton className="h-72 lg:col-span-2" /><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
  if (s.error || a.error) return <ErrorBox onRetry={() => { s.reload(); a.reload() }} />
  const sessions = s.data ?? []
  const alerts: { id: string; sev: Severity; title: string; sub: string; to: string }[] = [
    ...sessions.filter(x => !x.trusted && !x.current).map(x => ({ id: x.id, sev: 'high' as Severity, title: `Unrecognised session: ${x.device}`, sub: `${x.place}, ${ago(x.lastActive)}`, to: '/devices' })),
    ...pending.slice(0, 3).map(c => ({ id: c.id, sev: c.severity, title: c.title, sub: c.why, to: '/checklist' })),
  ]
  const tiles = [
    { icon: ShieldCheck, label: 'Checks complete', value: `${CHECKS.length - pending.length} of ${CHECKS.length}` },
    { icon: Laptop, label: 'Trusted devices', value: String(sessions.filter(x => x.trusted).length) },
    { icon: ListChecks, label: 'Open recommendations', value: String(pending.length) },
  ]
  return (
    <>
      <PageHeader title={`Welcome back, ${alias}`} sub="Your demo security posture, computed from the mock checks below. Nothing here is a real scan." />
      <div className="grid gap-4 lg:grid-cols-3">
        <section className="card flex flex-col items-center gap-3 text-center" aria-labelledby="h-score">
          <h2 id="h-score" className="font-semibold">Security health score</h2>
          <ScoreRing score={score} />
          <p className="muted">{g.tone === 'good' ? 'Nice work. Keep your checklist current.' : 'Complete high-impact checks to raise your score.'}</p>
          <Link to="/checklist" className="btn btn-primary">Review checklist</Link>
        </section>
        <section className="card lg:col-span-2" aria-labelledby="h-alerts">
          <h2 id="h-alerts" className="mb-3 font-semibold">Risk alerts <span className="muted font-normal">(simulated)</span></h2>
          {alerts.length === 0 ? <Empty title="No open alerts" text="All checks are complete and every session is trusted." /> : (
            <ul className="divide-y divide-slate-200 dark:divide-white/10">
              {alerts.map(x => (
                <li key={x.id}><Link to={x.to} className="flex items-center gap-3 rounded-lg py-3 hover:bg-slate-50 dark:hover:bg-white/5">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${DOT[x.sev]}`} /><span className="min-w-0 flex-1"><span className="block truncate font-medium">{x.title}</span><span className="muted block truncate">{x.sub}</span></span><Badge sev={x.sev} />
                </Link></li>
              ))}
            </ul>
          )}
        </section>
        {tiles.map(t => (
          <div key={t.label} className="card flex items-center gap-4"><div className="grid h-11 w-11 place-items-center rounded-lg bg-violet-500/10 text-violet-500"><t.icon size={22} /></div>
            <div><p className="text-2xl font-bold tabular-nums">{t.value}</p><p className="muted">{t.label}</p></div></div>
        ))}
        <section className="card lg:col-span-3" aria-labelledby="h-recent">
          <div className="mb-3 flex items-center justify-between"><h2 id="h-recent" className="font-semibold">Recent activity</h2><Link to="/activity" className="text-sm font-medium text-teal-600 hover:underline dark:text-teal-300">View all</Link></div>
          {(a.data ?? []).length === 0 ? <p className="muted">No activity yet. Changes you make will appear here.</p> : (
            <ul className="space-y-2">{(a.data ?? []).slice(0, 5).map(x => (
              <li key={x.id} className="flex items-center gap-3 text-sm"><span className={`h-2 w-2 shrink-0 rounded-full ${DOT[x.severity]}`} /><span className="flex-1">{x.title}</span><span className="muted shrink-0">{ago(x.at)}</span></li>
            ))}</ul>
          )}
        </section>
      </div>
    </>
  )
}
