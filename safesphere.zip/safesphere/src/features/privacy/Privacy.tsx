import { useState } from 'react'
import { Download, Trash2 } from 'lucide-react'
import { useToast } from '../../app/state'
import { useStored } from '../../lib/storage'
import { api } from '../../services/mockApi'
import { PageHeader, Switch } from '../../components/ui'

const OPTIONS = [
  { id: 'ads', label: 'Personalised ads', help: 'Use your activity to tailor the ads you see.' },
  { id: 'analytics', label: 'Share usage analytics', help: 'Send product usage data to improve the service.' },
  { id: 'location', label: 'Location history', help: 'Keep a record of places you sign in from.' },
  { id: 'public', label: 'Public profile', help: 'Let other people find and view your profile.' },
  { id: 'marketing', label: 'Marketing emails', help: 'Receive offers and product news.' },
]
export default function Privacy() {
  const [p, setP] = useStored<Record<string, boolean>>('privacy', { ads: true, analytics: true, location: false, public: true, marketing: false })
  const [days, setDays] = useStored<number>('retention', 365)
  const [ask, setAsk] = useState(false), toast = useToast()
  const safe = OPTIONS.filter(o => !p[o.id]).length
  function exportData() {
    const url = URL.createObjectURL(new Blob([api.exportData()], { type: 'application/json' }))
    const a = Object.assign(document.createElement('a'), { href: url, download: 'safesphere-demo-data.json' })
    a.click(); URL.revokeObjectURL(url); toast('Demo data exported')
  }
  return (
    <>
      <PageHeader title="Privacy settings" sub="Choose what this demo account shares. Settings are stored in this browser only.">
        <div className="card !py-2 text-sm"><span className="text-xl font-bold tabular-nums">{safe}/{OPTIONS.length}</span> <span className="muted">privacy-protective settings</span></div>
      </PageHeader>
      <ul className="card divide-y divide-slate-200 !py-0 dark:divide-white/10">
        {OPTIONS.map(o => (
          <li key={o.id} className="flex items-center gap-4 py-4">
            <div className="flex-1"><p className="font-medium">{o.label}</p><p className="muted">{o.help}</p></div>
            <span className="muted w-8 text-right">{p[o.id] ? 'On' : 'Off'}</span>
            <Switch label={o.label} checked={!!p[o.id]} onChange={v => { setP({ ...p, [o.id]: v }); api.log('privacy', `${o.label} turned ${v ? 'on' : 'off'}`); toast(`${o.label} turned ${v ? 'on' : 'off'}`, 'info') }} />
          </li>
        ))}
        <li className="flex items-center gap-4 py-4">
          <div className="flex-1"><label htmlFor="ret" className="font-medium">Activity retention</label><p className="muted">How long demo activity history is kept.</p></div>
          <select id="ret" className="input !w-auto" value={days} onChange={e => { setDays(Number(e.target.value)); toast(`Retention set to ${e.target.value} days`, 'info') }}>
            {[30, 90, 365].map(d => <option key={d} value={d}>{d} days</option>)}
          </select>
        </li>
      </ul>
      <div className="mt-4 flex flex-wrap gap-2">
        <button className="btn" onClick={exportData}><Download size={16} />Export demo data</button>
        <button className="btn btn-danger" onBlur={() => setAsk(false)} onClick={() => { if (ask) { api.resetDemo(); location.reload() } else setAsk(true) }}><Trash2 size={16} />{ask ? 'Click again to delete' : 'Delete all demo data'}</button>
      </div>
    </>
  )
}
