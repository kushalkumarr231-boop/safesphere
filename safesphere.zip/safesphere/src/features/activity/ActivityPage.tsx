import { useState } from 'react'
import { History, Trash2 } from 'lucide-react'
import { useToast } from '../../app/state'
import { useAsync } from '../../lib/useAsync'
import { api } from '../../services/mockApi'
import { Badge, DOT, Empty, ErrorBox, PageHeader, Skeleton, ago } from '../../components/ui'

export default function ActivityPage() {
  const a = useAsync(api.activity), toast = useToast()
  const [f, setF] = useState('all')
  const list = (a.data ?? []).filter(x => f === 'all' || x.severity === f)
  return (
    <>
      <PageHeader title="Activity timeline" sub="Sample events plus every change you make in this demo. Monitoring here is simulated.">
        <div className="flex gap-2">
          <label className="sr-only" htmlFor="sev">Filter by severity</label>
          <select id="sev" className="input !w-auto" value={f} onChange={e => setF(e.target.value)}>
            <option value="all">All severities</option>{['critical', 'high', 'medium', 'low'].map(s => <option key={s} value={s}>{s[0].toUpperCase() + s.slice(1)}</option>)}
          </select>
          <button className="btn" disabled={!(a.data ?? []).length} onClick={() => { api.clearActivity(); a.setData([]); toast('Timeline cleared', 'info') }}><Trash2 size={16} />Clear</button>
        </div>
      </PageHeader>
      {a.loading ? <div className="space-y-3" aria-busy="true">{[0, 1, 2, 3].map(i => <Skeleton key={i} className="h-14" />)}</div> : a.error ? <ErrorBox onRetry={a.reload} /> : list.length === 0 ? (
        <Empty icon={History} title="No events to show" text={f === 'all' ? 'Changes you make, like completing a check or revoking a session, will appear here.' : 'No events match this severity. Choose another filter.'} />
      ) : (
        <ol className="relative ml-2 border-l border-slate-300 pl-6 dark:border-white/15">{list.map(x => (
          <li key={x.id} className="relative pb-5">
            <span className={`absolute -left-[31px] top-1.5 h-3 w-3 rounded-full ring-4 ring-slate-50 dark:ring-ink-900 ${DOT[x.severity]}`} />
            <div className="card !p-3"><p className="text-sm font-medium">{x.title}</p><p className="muted mt-1 flex items-center gap-2"><Badge sev={x.severity} /><span className="capitalize">{x.kind}</span><span>{ago(x.at)}</span></p></div>
          </li>
        ))}</ol>
      )}
    </>
  )
}
