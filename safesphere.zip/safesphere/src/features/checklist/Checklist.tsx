import { useState } from 'react'
import { PartyPopper, RotateCcw } from 'lucide-react'
import { useChecklist } from '../../app/state'
import { CHECKS } from '../../lib/score'
import { Badge, Empty, PageHeader } from '../../components/ui'

const FILTERS = [['all', 'All'], ['todo', 'To do'], ['done', 'Done']] as const
export default function Checklist() {
  const { done, toggle, score, reset } = useChecklist()
  const [f, setF] = useState<(typeof FILTERS)[number][0]>('all')
  const shown = CHECKS.filter(c => f === 'all' || (f === 'done') === !!done[c.id])
  return (
    <>
      <PageHeader title="Security checklist" sub="Each check carries a weight. Your health score is the weighted share you have completed.">
        <button className="btn" onClick={reset}><RotateCcw size={16} />Reset checklist</button>
      </PageHeader>
      <div className="card mb-4">
        <div className="mb-2 flex justify-between text-sm font-medium"><span>Progress</span><span className="tabular-nums">{score}/100 points</span></div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10" role="progressbar" aria-valuenow={score} aria-valuemin={0} aria-valuemax={100} aria-label="Checklist progress">
          <div className="h-full rounded-full bg-gradient-to-r from-teal-400 to-violet-500 transition-all duration-500" style={{ width: `${score}%` }} />
        </div>
      </div>
      <div className="mb-4 flex gap-2" role="group" aria-label="Filter checks">
        {FILTERS.map(([k, l]) => <button key={k} aria-pressed={f === k} onClick={() => setF(k)} className={`btn ${f === k ? '!border-teal-400 bg-teal-500/10' : ''}`}>{l}</button>)}
      </div>
      {shown.length === 0 ? <Empty icon={PartyPopper} title="Nothing in this view" text={f === 'todo' ? 'Every check is complete. Great work.' : 'No checks are complete yet. Tick one off to start.'} /> : (
        <ul className="space-y-3">{shown.map(c => (
          <li key={c.id}><label className="card flex cursor-pointer items-start gap-4 transition hover:border-teal-400/60">
            <input type="checkbox" className="mt-1 h-5 w-5 shrink-0 accent-teal-500" checked={!!done[c.id]} onChange={() => toggle(c.id)} />
            <span className="min-w-0 flex-1"><span className={`block font-medium ${done[c.id] ? 'text-slate-400 line-through' : ''}`}>{c.title}</span><span className="muted block">{c.why}</span><span className="muted mt-1 block text-xs">{c.area}, worth {c.weight} points</span></span>
            <Badge sev={c.severity} />
          </label></li>
        ))}</ul>
      )}
    </>
  )
}
