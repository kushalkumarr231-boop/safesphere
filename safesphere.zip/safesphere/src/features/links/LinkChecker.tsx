import { useState, type FormEvent } from 'react'
import { Loader2, Search, Trash2 } from 'lucide-react'
import { useChecklist, useToast } from '../../app/state'
import { analyzeUrl, type Level, type UrlResult } from '../../lib/url'
import { useStored } from '../../lib/storage'
import { api } from '../../services/mockApi'
import { Badge, DOT, PageHeader, ago } from '../../components/ui'

const SAMPLES = ['https://github.com', 'http://paypal-secure-login.xyz/verify', 'http://192.168.4.7/account/update']
type Ok = Extract<UrlResult, { ok: true }>
export default function LinkChecker() {
  const [url, setUrl] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false), [res, setRes] = useState<Ok | null>(null)
  const [hist, setHist] = useStored<{ host: string; level: Level; at: string }[]>('link-history', [])
  const toast = useToast(), { done, toggle } = useChecklist()
  async function submit(e: FormEvent) {
    e.preventDefault()
    const r = analyzeUrl(url)
    if (!r.ok) { setErr(r.error); setRes(null); return }
    setErr(''); setBusy(true); setRes(null)
    await new Promise(t => setTimeout(t, 600))
    setBusy(false); setRes(r)
    setHist(h => [{ host: r.host, level: r.level, at: new Date().toISOString() }, ...h].slice(0, 6))
    api.log('link', `Checked link (${r.host}): ${r.level} risk, heuristic`, r.level === 'high' ? 'high' : 'low')
    toast(`Heuristic check finished: ${r.level} risk`, r.level === 'high' ? 'err' : 'ok')
  }
  return (
    <>
      <PageHeader title="Link checker" sub="Paste a link to see which common phishing patterns it matches. This is an offline heuristic. The link is never opened or sent anywhere." />
      <form onSubmit={submit} className="card mb-4" noValidate>
        <label htmlFor="url" className="mb-2 block text-sm font-medium">Link to check</label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input id="url" className="input" value={url} placeholder="example.com/login" autoComplete="off" spellCheck={false} aria-invalid={!!err} aria-describedby={err ? 'url-err' : undefined} onChange={e => setUrl(e.target.value)} />
          <button className="btn btn-primary shrink-0" disabled={busy}>{busy ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}{busy ? 'Checking' : 'Check link'}</button>
        </div>
        {err && <p id="url-err" role="alert" className="mt-2 text-sm text-rose-500">{err}</p>}
        <p className="muted mt-3">Try a sample: {SAMPLES.map(x => <button type="button" key={x} onClick={() => { setUrl(x); setErr('') }} className="mr-2 rounded bg-slate-100 px-2 py-0.5 text-xs hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/20">{x.replace(/^https?:\/\//, '')}</button>)}</p>
        <p className="muted mt-2 text-xs">Do not paste links that contain passwords, tokens, or private data.</p>
      </form>
      {res && (
        <section className="card mb-4" aria-live="polite">
          <div className="mb-3 flex flex-wrap items-center gap-3"><h2 className="font-semibold">{res.host}</h2><Badge sev={res.level}>{res.level} risk</Badge><span className="muted ml-auto">Mock heuristic result</span></div>
          <div className="mb-3 h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10" role="meter" aria-valuenow={res.risk} aria-valuemin={0} aria-valuemax={100} aria-label="Heuristic risk">
            <div className={`h-full rounded-full ${DOT[res.level]}`} style={{ width: `${Math.max(res.risk, 4)}%` }} />
          </div>
          <ul className="list-disc space-y-1 pl-5 text-sm">{res.reasons.map(x => <li key={x}>{x}</li>)}</ul>
          {!done.phi && <button className="btn mt-4" onClick={() => toggle('phi')}>Mark phishing awareness as done</button>}
        </section>
      )}
      <section className="card" aria-labelledby="h-hist">
        <div className="mb-2 flex items-center justify-between"><h2 id="h-hist" className="font-semibold">Recent checks</h2>
          {hist.length > 0 && <button className="btn !py-1" onClick={() => { setHist([]); toast('Link history cleared', 'info') }}><Trash2 size={14} />Clear</button>}</div>
        {hist.length === 0 ? <p className="muted">No checks yet. Only the domain name and result are saved, in this browser.</p> : (
          <ul className="space-y-2 text-sm">{hist.map((h, i) => <li key={i} className="flex items-center gap-2"><span className="flex-1 truncate">{h.host}</span><Badge sev={h.level} /><span className="muted w-20 text-right">{ago(h.at)}</span></li>)}</ul>
        )}
      </section>
    </>
  )
}
