export type Severity = 'critical' | 'high' | 'medium' | 'low'
export interface Check { id: string; title: string; why: string; weight: number; severity: Severity; area: string }
export type Done = Record<string, boolean>

/** Mock security checks. Weights sum to 100, so the score is a plain weighted percentage. */
export const CHECKS: Check[] = [
  { id: 'mfa', title: 'Enable multi-factor authentication', why: 'Stops most credential-stuffing takeovers.', weight: 20, severity: 'critical', area: 'Accounts' },
  { id: 'pwm', title: 'Use a password manager', why: 'Unique passwords limit the damage of any one breach.', weight: 15, severity: 'high', area: 'Accounts' },
  { id: 'upd', title: 'Turn on automatic updates', why: 'Patches close known vulnerabilities quickly.', weight: 15, severity: 'high', area: 'Devices' },
  { id: 'rec', title: 'Review account recovery options', why: 'Stale recovery emails are a common takeover path.', weight: 10, severity: 'medium', area: 'Accounts' },
  { id: 'bak', title: 'Keep a tested backup', why: 'A good backup turns ransomware into an inconvenience.', weight: 10, severity: 'medium', area: 'Devices' },
  { id: 'ses', title: 'Review signed-in devices', why: 'Remove sessions you do not recognise.', weight: 10, severity: 'medium', area: 'Devices' },
  { id: 'prv', title: 'Tighten privacy settings', why: 'Less shared data means less exposure.', weight: 10, severity: 'low', area: 'Privacy' },
  { id: 'phi', title: 'Learn to spot phishing links', why: 'Most attacks begin with a message.', weight: 10, severity: 'low', area: 'Awareness' },
]
const RANK: Record<Severity, number> = { critical: 4, high: 3, medium: 2, low: 1 }

export function computeScore(done: Done, checks: Check[] = CHECKS): number {
  const total = checks.reduce((s, c) => s + c.weight, 0)
  const got = checks.reduce((s, c) => s + (done[c.id] ? c.weight : 0), 0)
  return total ? Math.round((got / total) * 100) : 0
}
export function grade(score: number): { label: string; tone: 'good' | 'warn' | 'bad' } {
  if (score >= 85) return { label: 'Strong', tone: 'good' }
  if (score >= 60) return { label: 'Good', tone: 'good' }
  if (score >= 40) return { label: 'Fair', tone: 'warn' }
  return { label: 'At risk', tone: 'bad' }
}
/** Open checks, highest impact (severity x weight) first. */
export function pendingChecks(done: Done, checks: Check[] = CHECKS): Check[] {
  return checks.filter(c => !done[c.id]).sort((a, b) => RANK[b.severity] * b.weight - RANK[a.severity] * a.weight)
}
