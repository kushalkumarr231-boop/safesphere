import { useCallback, useEffect, useState } from 'react'
export function useAsync<T>(fn: () => Promise<T>) {
  const [s, set] = useState<{ data: T | null; loading: boolean; error: boolean }>({ data: null, loading: true, error: false })
  const run = useCallback(() => {
    set(p => ({ ...p, loading: true, error: false }))
    fn().then(data => set({ data, loading: false, error: false }), () => set({ data: null, loading: false, error: true }))
  }, [fn])
  useEffect(run, [run])
  return { ...s, reload: run, setData: (data: T) => set({ data, loading: false, error: false }) }
}
