import { describe, expect, it } from 'vitest'
import { CHECKS, computeScore, grade, pendingChecks } from './score'

describe('score', () => {
  it('weights sum to 100', () => expect(CHECKS.reduce((s, c) => s + c.weight, 0)).toBe(100))
  it('is 0 with nothing done and 100 with everything done', () => {
    expect(computeScore({})).toBe(0)
    expect(computeScore(Object.fromEntries(CHECKS.map(c => [c.id, true])))).toBe(100)
  })
  it('adds the weight of completed checks', () => {
    expect(computeScore({ mfa: true })).toBe(20)
    expect(computeScore({ mfa: true, pwm: true, phi: false })).toBe(35)
  })
  it('ignores unknown ids and handles empty check lists', () => {
    expect(computeScore({ nope: true })).toBe(0)
    expect(computeScore({}, [])).toBe(0)
  })
  it('maps scores to grades at the boundaries', () => {
    expect(grade(85).label).toBe('Strong'); expect(grade(84).label).toBe('Good')
    expect(grade(60).label).toBe('Good'); expect(grade(59).label).toBe('Fair')
    expect(grade(40).label).toBe('Fair'); expect(grade(39)).toEqual({ label: 'At risk', tone: 'bad' })
  })
  it('lists open checks by impact and omits completed ones', () => {
    const p = pendingChecks({ mfa: true })
    expect(p[0].id).toBe('pwm'); expect(p.find(c => c.id === 'mfa')).toBeUndefined()
    expect(pendingChecks({})[0].id).toBe('mfa')
  })
})
