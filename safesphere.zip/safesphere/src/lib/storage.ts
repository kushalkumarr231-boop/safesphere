import { useEffect, useState, type Dispatch, type SetStateAction } from 'react'
const P = 'safesphere:'
export function load<T>(k: string, fb: T): T {
  try { const v = localStorage.getItem(P + k); return v === null ? fb : (JSON.parse(v) as T) } catch { return fb }
}
export function save(k: string, v: unknown): void {
  try { localStorage.setItem(P + k, JSON.stringify(v)) } catch { /* quota or private mode: demo keeps working in memory */ }
}
export const dump = (): Record<string, unknown> =>
  Object.fromEntries(Object.keys(localStorage).filter(k => k.startsWith(P)).map(k => [k.slice(P.length), load(k.slice(P.length), null)]))
export const wipe = (): void => { Object.keys(localStorage).filter(k => k.startsWith(P)).forEach(k => localStorage.removeItem(k)) }
export function useStored<T>(k: string, init: T): [T, Dispatch<SetStateAction<T>>] {
  const [v, set] = useState<T>(() => load(k, init))
  useEffect(() => save(k, v), [k, v])
  return [v, set]
}
