import { describe, expect, it } from 'vitest'
import { analyzeUrl } from './url'

const ok = (s: string) => { const r = analyzeUrl(s); if (!r.ok) throw new Error(r.error); return r }
describe('analyzeUrl', () => {
  it('rejects empty, spaced, invalid and non-web input', () => {
    for (const bad of ['', '   ', 'has space.com', 'ftp://example.com', 'javascript:alert(1)', 'localhost']) expect(analyzeUrl(bad).ok).toBe(false)
  })
  it('adds https when the scheme is missing', () => expect(ok('example.com').host).toBe('example.com'))
  it('rates a plain https site as low risk', () => expect(ok('https://github.com').level).toBe('low'))
  it('flags http + raw IP + keywords as high risk', () => {
    const r = ok('http://192.168.4.7/account/update')
    expect(r.level).toBe('high'); expect(r.risk).toBeGreaterThanOrEqual(50)
  })
  it('flags brand look-alikes but not the real domain', () => {
    expect(ok('https://paypal-secure-login.xyz/verify').level).toBe('high')
    expect(ok('https://www.paypal.com').level).toBe('low')
  })
  it('flags embedded credentials and punycode', () => {
    expect(ok('https://user:pw@example.com').reasons.join(' ')).toMatch(/credentials/)
    expect(ok('https://xn--pple-43d.com').reasons.join(' ')).toMatch(/punycode/)
  })
  it('caps risk at 100', () => expect(ok('http://user@paypal-login-secure-verify.xyz/account/password/update/' + 'a'.repeat(100)).risk).toBeLessThanOrEqual(100))
})
