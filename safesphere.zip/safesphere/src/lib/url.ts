export type Level = 'low' | 'medium' | 'high'
export type UrlResult = { ok: true; host: string; risk: number; level: Level; reasons: string[] } | { ok: false; error: string }
const BRANDS = ['paypal', 'google', 'apple', 'microsoft', 'amazon', 'netflix', 'facebook']
const TLDS = ['zip', 'xyz', 'top', 'click', 'tk', 'ml', 'gq', 'work']
const SHORT = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'is.gd']
const WORDS = ['login', 'verify', 'secure', 'update', 'account', 'wallet', 'password', 'signin', 'confirm']

/** Offline heuristic only: it never fetches or contacts the URL. */
export function analyzeUrl(raw: string): UrlResult {
  const s = raw.trim()
  if (!s) return { ok: false, error: 'Enter a link to check.' }
  if (s.length > 2048 || /\s/.test(s)) return { ok: false, error: 'Links must be under 2048 characters and contain no spaces.' }
  let u: URL
  try { u = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(s) ? s : 'https://' + s) } catch { return { ok: false, error: 'That does not look like a valid link.' } }
  if (!['http:', 'https:'].includes(u.protocol)) return { ok: false, error: 'Only http and https links can be checked.' }
  const host = u.hostname.toLowerCase()
  if (!host.includes('.') && !host.startsWith('[')) return { ok: false, error: 'Enter a full domain, such as example.com.' }
  const labels = host.split('.'), reg = labels.slice(-2).join('.'), tld = labels[labels.length - 1]
  const reasons: string[] = []
  let risk = 0
  const add = (n: number, r: string) => { risk += n; reasons.push(r) }
  if (u.protocol === 'http:') add(20, 'The connection is not encrypted (http).')
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host.startsWith('[')) add(30, 'Uses a raw IP address instead of a domain name.')
  if (host.includes('xn--')) add(25, 'Contains punycode, which can disguise look-alike characters.')
  if (u.username || u.password) add(25, 'Contains embedded credentials, a common link-disguise trick.')
  if (labels.length > 4) add(10, 'Unusually deep chain of subdomains.')
  if (TLDS.includes(tld)) add(15, `The .${tld} ending is frequently abused.`)
  if (SHORT.includes(host)) add(15, 'A URL shortener hides the real destination.')
  if ((host.match(/-/g) || []).length >= 3) add(10, 'Many hyphens in the domain name.')
  const brand = BRANDS.find(b => host.includes(b) && reg !== b + '.com')
  if (brand) add(30, `Mentions "${brand}" but is not the official ${brand}.com domain.`)
  const hits = WORDS.filter(w => (host + u.pathname).toLowerCase().includes(w))
  if (hits.length) add(Math.min(20, hits.length * 10), `Contains credential or urgency keywords: ${hits.join(', ')}.`)
  if (s.length > 100) add(10, 'Very long link.')
  risk = Math.min(100, risk)
  if (!reasons.length) reasons.push('No common phishing patterns matched. That does not guarantee the link is safe.')
  return { ok: true, host, risk, level: risk >= 50 ? 'high' : risk >= 25 ? 'medium' : 'low', reasons }
}
