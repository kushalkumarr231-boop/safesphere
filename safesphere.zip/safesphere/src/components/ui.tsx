import type { ElementType, ReactNode } from 'react'
import { AlertTriangle, Inbox } from 'lucide-react'
import { grade, type Severity } from '../lib/score'

const SEV: Record<Severity, string> = {
  critical: 'bg-rose-500/10 text-rose-600 ring-rose-500/30 dark:text-rose-300',
  high: 'bg-orange-500/10 text-orange-600 ring-orange-500/30 dark:text-orange-300',
  medium: 'bg-amber-500/10 text-amber-700 ring-amber-500/30 dark:text-amber-300',
  low: 'bg-teal-500/10 text-teal-700 ring-teal-500/30 dark:text-teal-300',
}
export const DOT: Record<Severity, string> = { critical: 'bg-rose-500', high: 'bg-orange-500', medium: 'bg-amber-500', low: 'bg-teal-400' }
export const Badge = ({ sev, children }: { sev: Severity; children?: ReactNode }) => (
  <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium capitalize ring-1 ${SEV[sev]}`}>{children ?? sev}</span>
)
export const PageHeader = ({ title, sub, children }: { title: string; sub: string; children?: ReactNode }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div><h1 className="text-2xl font-bold tracking-tight">{title}</h1><p className="muted mt-1 max-w-xl">{sub}</p></div>{children}
  </div>
)
export const Skeleton = ({ className = '' }: { className?: string }) => <div aria-hidden className={`animate-pulse rounded-xl bg-slate-200 dark:bg-white/10 ${className}`} />
export function Empty({ icon: Icon = Inbox, title, text }: { icon?: ElementType; title: string; text: string }) {
  return (
    <div className="card flex flex-col items-center gap-2 py-10 text-center">
      <div className="grid h-11 w-11 place-items-center rounded-full bg-teal-500/10 text-teal-500"><Icon size={22} /></div>
      <p className="font-semibold">{title}</p><p className="muted max-w-sm">{text}</p>
    </div>
  )
}
export const ErrorBox = ({ onRetry }: { onRetry: () => void }) => (
  <div className="card flex items-center gap-3 border-rose-300 dark:border-rose-500/40" role="alert">
    <AlertTriangle className="text-rose-500" size={20} /><p className="flex-1 text-sm">Could not load this data from the mock service.</p>
    <button className="btn" onClick={onRetry}>Retry</button>
  </div>
)
export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? 'bg-teal-500' : 'bg-slate-300 dark:bg-white/20'}`}>
      <span className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-5' : ''}`} />
    </button>
  )
}
export function ScoreRing({ score }: { score: number }) {
  const g = grade(score), r = 52, c = 2 * Math.PI * r
  const stroke = g.tone === 'bad' ? '#f43f5e' : g.tone === 'warn' ? '#f59e0b' : 'url(#sg)'
  return (
    <div className="relative h-44 w-44" role="img" aria-label={`Security health score ${score} out of 100, rated ${g.label}`}>
      <svg viewBox="0 0 120 120" className="-rotate-90">
        <defs><linearGradient id="sg" x1="0" x2="1"><stop offset="0" stopColor="#2dd4bf" /><stop offset="1" stopColor="#8b5cf6" /></linearGradient></defs>
        <circle cx="60" cy="60" r={r} fill="none" strokeWidth="8" className="stroke-slate-200 dark:stroke-white/10" />
        <circle cx="60" cy="60" r={r} fill="none" strokeWidth="8" strokeLinecap="round" stroke={stroke} strokeDasharray={c} strokeDashoffset={c * (1 - score / 100)} style={{ transition: 'stroke-dashoffset .8s ease' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center"><div>
        <div className="text-5xl font-bold tabular-nums tracking-tight">{score}</div><div className="muted -mt-1">{g.label}</div>
      </div></div>
    </div>
  )
}
export function ago(iso: string) {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000))
  if (m < 1) return 'just now'
  if (m < 60) return `${m} min ago`
  if (m < 1440) return `${Math.round(m / 60)} h ago`
  return `${Math.round(m / 1440)} d ago`
}
