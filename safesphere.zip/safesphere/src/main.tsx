import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './app/App'
import { ChecklistProvider, ThemeProvider, ToastProvider } from './app/state'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode><BrowserRouter><ThemeProvider><ToastProvider><ChecklistProvider><App /></ChecklistProvider></ToastProvider></ThemeProvider></BrowserRouter></StrictMode>,
)
