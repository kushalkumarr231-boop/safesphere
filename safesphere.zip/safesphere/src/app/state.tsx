import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react'
import { useStored } from '../lib/storage'
import { CHECKS, computeScore, type Done } from '../lib/score'
import { api } from '../services/mockApi'

type Theme = 'light' | 'dark'
const ThemeCtx = createContext<{ theme: Theme; setTheme: (t: Theme) => void }>({ theme: 'dark', setTheme: () => {} })
export const useTheme = () => useContext(ThemeCtx)
export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useStored<Theme>('theme', matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  useEffect(() => { document.documentElement.classList.toggle('dark', theme === 'dark') }, [theme])
  return <ThemeCtx.Provider value={{ theme, setTheme }}>{children}</ThemeCtx.Provider>
}

type Tone = 'ok' | 'err' | 'info'
const ToastCtx = createContext<(msg: string, tone?: Tone) => void>(() => {})
export const useToast = () => useContext(ToastCtx)
export function ToastProvider({ children }: { children: ReactNode }) {
  const [list, setList] = useState<{ id: number; msg: string; tone: Tone }[]>([])
  const drop = (id: number) => setList(l => l.filter(t => t.id !== id))
  const push = useCallback((msg: string, tone: Tone = 'ok') => {
    const id = Date.now() + Math.random()
    setList(l => [...l, { id, msg, tone }].slice(-4))
    setTimeout(() => setList(l => l.filter(t => t.id !== id)), 4000)
  }, [])
  const Icon = { ok: CheckCircle2, err: AlertCircle, info: Info }
  const color = { ok: 'text-teal-500', err: 'text-rose-500', info: 'text-violet-400' }
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 right-4 z-50 flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2" role="status" aria-live="polite">
        {list.map(t => { const I = Icon[t.tone]; return (
          <div key={t.id} className="rise card flex items-start gap-2 !p-3 text-sm shadow-lg">
            <I size={18} className={`mt-0.5 shrink-0 ${color[t.tone]}`} /><span className="flex-1">{t.msg}</span>
            <button aria-label="Dismiss notification" onClick={() => drop(t.id)} className="rounded p-0.5 text-slate-400 hover:text-slate-700 dark:hover:text-white"><X size={14} /></button>
          </div>) })}
      </div>
    </ToastCtx.Provider>
  )
}

interface CheckState { done: Done; score: number; toggle: (id: string) => void; reset: () => void }
const CheckCtx = createContext<CheckState>({ done: {}, score: 0, toggle: () => {}, reset: () => {} })
export const useChecklist = () => useContext(CheckCtx)
export function ChecklistProvider({ children }: { children: ReactNode }) {
  const [done, setDone] = useStored<Done>('checklist', { pwm: true, upd: true, rec: true })
  const toast = useToast()
  const toggle = useCallback((id: string) => {
    const c = CHECKS.find(x => x.id === id)
    if (!c) return
    const next = !done[id]
    setDone({ ...done, [id]: next })
    api.log('checklist', `${next ? 'Completed' : 'Reopened'}: ${c.title}`, next ? 'low' : c.severity)
    toast(next ? `Completed: ${c.title} (+${c.weight} pts)` : `Reopened: ${c.title}`, next ? 'ok' : 'info')
  }, [done, setDone, toast])
  const reset = useCallback(() => { setDone({}); api.log('checklist', 'Checklist reset', 'medium'); toast('Checklist reset', 'info') }, [setDone, toast])
  return <CheckCtx.Provider value={{ done, score: computeScore(done), toggle, reset }}>{children}</CheckCtx.Provider>
}
