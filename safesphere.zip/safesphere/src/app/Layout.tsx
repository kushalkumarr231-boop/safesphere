import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { Bell, History, Laptop, LayoutDashboard, Link2, ListChecks, Lock, Menu, Moon, Settings, Shield, Sun, X } from 'lucide-react'
import { pendingChecks } from '../lib/score'
import { useChecklist, useTheme } from './state'

const NAV = [
  { to: '/', label: 'Overview', icon: LayoutDashboard },
  { to: '/checklist', label: 'Checklist', icon: ListChecks },
  { to: '/link-checker', label: 'Link checker', icon: Link2 },
  { to: '/devices', label: 'Devices', icon: Laptop },
  { to: '/privacy', label: 'Privacy', icon: Lock },
  { to: '/activity', label: 'Activity', icon: History },
  { to: '/settings', label: 'Settings', icon: Settings },
]
export default function Layout() {
  const [open, setOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const { done } = useChecklist()
  const { pathname } = useLocation()
  const main = useRef<HTMLElement>(null), first = useRef(true)
  const urgent = pendingChecks(done).filter(c => c.severity === 'critical' || c.severity === 'high').length
  useEffect(() => {
    setOpen(false)
    if (first.current) first.current = false; else main.current?.focus({ preventScroll: true })
  }, [pathname])
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    addEventListener('keydown', k); return () => removeEventListener('keydown', k)
  }, [])
  const title = NAV.find(n => n.to === pathname)?.label ?? 'SafeSphere'
  return (
    <div className="min-h-screen">
      <a href="#main" className="sr-only z-50 rounded bg-teal-500 px-3 py-2 text-white focus:not-sr-only focus:fixed focus:left-3 focus:top-3">Skip to content</a>
      {open && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setOpen(false)} aria-hidden />}
      <aside aria-label="Sidebar" className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-white/10 bg-ink-900 p-4 text-slate-300 transition-transform lg:visible lg:translate-x-0 ${open ? '' : 'invisible -translate-x-full'}`}>
        <div className="mb-6 flex items-center gap-2 px-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-teal-400 to-violet-500 text-ink-900"><Shield size={20} strokeWidth={2.5} /></div>
          <span className="text-lg font-bold tracking-tight text-white">SafeSphere</span>
          <button className="ml-auto rounded p-1 lg:hidden" aria-label="Close navigation" onClick={() => setOpen(false)}><X size={18} /></button>
        </div>
        <nav aria-label="Primary" className="flex flex-1 flex-col gap-1">
          {NAV.map(({ to, label, icon: I }) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `flex items-center gap-3 rounded-lg border-l-2 px-3 py-2 text-sm font-medium transition ${isActive ? 'border-teal-400 bg-white/10 text-white' : 'border-transparent text-slate-400 hover:bg-white/5 hover:text-white'}`}>
              <I size={18} />{label}
            </NavLink>
          ))}
        </nav>
        <p className="rounded-lg border border-violet-400/30 bg-violet-500/10 p-3 text-xs leading-relaxed text-violet-200">Demo mode. All results are mocked and monitoring is simulated. No real account is scanned or protected.</p>
      </aside>
      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-slate-200 bg-slate-50/80 px-4 backdrop-blur dark:border-white/10 dark:bg-ink-900/80 sm:px-8">
          <button className="btn !p-2 lg:hidden" aria-label="Open navigation" aria-expanded={open} onClick={() => setOpen(true)}><Menu size={18} /></button>
          <p className="font-semibold">{title}</p>
          <span className="ml-auto hidden rounded-full bg-violet-500/10 px-2.5 py-1 text-xs font-medium text-violet-600 ring-1 ring-violet-500/30 dark:text-violet-300 sm:inline">Simulated data</span>
          <Link to="/checklist" className="btn relative !p-2" aria-label={`${urgent} high-priority recommendations. Open checklist`}>
            <Bell size={18} />{urgent > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">{urgent}</span>}
          </Link>
          <button className="btn !p-2" aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`} onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </header>
        <main id="main" ref={main} tabIndex={-1} className="mx-auto max-w-6xl p-4 outline-none sm:p-8"><Outlet /></main>
      </div>
    </div>
  )
}
