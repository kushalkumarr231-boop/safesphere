import { Link, Route, Routes } from 'react-router-dom'
import Layout from './Layout'
import Overview from '../features/dashboard/Overview'
import Checklist from '../features/checklist/Checklist'
import LinkChecker from '../features/links/LinkChecker'
import Devices from '../features/devices/Devices'
import Privacy from '../features/privacy/Privacy'
import ActivityPage from '../features/activity/ActivityPage'
import SettingsPage from '../features/settings/SettingsPage'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Overview />} />
        <Route path="checklist" element={<Checklist />} />
        <Route path="link-checker" element={<LinkChecker />} />
        <Route path="devices" element={<Devices />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="activity" element={<ActivityPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<div className="card text-center"><h1 className="text-xl font-bold">Page not found</h1><p className="muted my-2">That address does not exist in SafeSphere.</p><Link className="btn btn-primary" to="/">Back to overview</Link></div>} />
      </Route>
    </Routes>
  )
}
