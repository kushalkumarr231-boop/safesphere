import { dump, load, save, wipe } from '../lib/storage'
import type { Severity } from '../lib/score'

export interface Session { id: string; device: string; os: string; place: string; lastActive: string; current: boolean; trusted: boolean }
export type Kind = 'checklist' | 'device' | 'privacy' | 'link' | 'system'
export interface Activity { id: string; kind: Kind; title: string; at: string; severity: Severity }

const LATENCY = Number(import.meta.env.VITE_MOCK_LATENCY_MS ?? 450)
const wait = (ms = LATENCY) => new Promise<void>(r => setTimeout(r, ms + Math.random() * 250))
const ago = (m: number) => new Date(Date.now() - m * 60000).toISOString()
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36)

const seedSessions = (): Session[] => [
  { id: 's1', device: 'Studio laptop · Chrome', os: 'macOS 14', place: 'Home network', lastActive: ago(0), current: true, trusted: true },
  { id: 's2', device: 'Pixel 8 · Mobile app', os: 'Android 15', place: 'Home network', lastActive: ago(42), current: false, trusted: true },
  { id: 's3', device: 'Tablet · Safari', os: 'iPadOS 17', place: 'Regional ISP', lastActive: ago(26 * 60), current: false, trusted: false },
  { id: 's4', device: 'Windows PC · Edge', os: 'Windows 11', place: 'Frankfurt, DE', lastActive: ago(50 * 60), current: false, trusted: false },
  { id: 's5', device: 'Unknown Linux · Firefox', os: 'Linux', place: 'Lagos, NG', lastActive: ago(5 * 60), current: false, trusted: false },
]
const seedActivity = (): Activity[] => [
  { id: 'a1', kind: 'device', title: 'New sign-in from Lagos, NG (simulated)', at: ago(5 * 60), severity: 'high' },
  { id: 'a2', kind: 'system', title: 'Simulated monitor found a password reused across 2 demo accounts', at: ago(9 * 60), severity: 'medium' },
  { id: 'a3', kind: 'device', title: 'Pixel 8 marked as trusted', at: ago(30 * 60), severity: 'low' },
  { id: 'a4', kind: 'checklist', title: 'Completed: Review account recovery options', at: ago(2 * 24 * 60), severity: 'low' },
  { id: 'a5', kind: 'system', title: 'Simulated breach-monitor scan finished: 0 new exposures', at: ago(3 * 24 * 60), severity: 'low' },
  { id: 'a6', kind: 'privacy', title: 'Location history turned off', at: ago(6 * 24 * 60), severity: 'low' },
]
function table<T>(key: string, seed: () => T[]): T[] {
  const v = load<T[] | null>(key, null)
  if (v) return v
  const s = seed(); save(key, s); return s
}
const sessions = () => table<Session>('sessions', seedSessions)

/** Stand-in for a real backend. Everything here is simulated and stored in this browser only. */
export const api = {
  async sessions() { await wait(); return sessions() },
  async activity() { await wait(); return table<Activity>('activity', seedActivity) },
  async setTrust(id: string, trusted: boolean) {
    await wait(250)
    const next = sessions().map(s => (s.id === id ? { ...s, trusted } : s)); save('sessions', next)
    api.log('device', `${next.find(s => s.id === id)?.device ?? 'Session'} marked as ${trusted ? 'trusted' : 'unrecognised'}`, trusted ? 'low' : 'medium')
    return next
  },
  async revoke(id: string) {
    await wait(250)
    const name = sessions().find(s => s.id === id)?.device ?? 'Session'
    const next = sessions().filter(s => s.id !== id); save('sessions', next)
    api.log('device', `Revoked session: ${name}`, 'medium')
    return next
  },
  async revokeOthers() {
    await wait(250)
    const next = sessions().filter(s => s.current); save('sessions', next)
    api.log('device', 'Signed out all other sessions', 'medium')
    return next
  },
  log(kind: Kind, title: string, severity: Severity = 'low') {
    const a = table<Activity>('activity', seedActivity)
    save('activity', [{ id: uid(), kind, title, at: new Date().toISOString(), severity }, ...a].slice(0, 100))
  },
  clearActivity() { save('activity', []) },
  exportData: () => JSON.stringify({ notice: 'SafeSphere demo data. Simulated, stored in this browser only.', exportedAt: new Date().toISOString(), data: dump() }, null, 2),
  resetDemo() { wipe() },
}
